import type { Request, Response } from 'express';
import express from 'express';
import { registerRoutes } from '../server/routes';

const app = express();

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Initialize routes
let routesInitialized = false;

export default async function handler(req: Request, res: Response) {
  if (!routesInitialized) {
    await registerRoutes(app);
    routesInitialized = true;
  }

  return new Promise((resolve) => {
    app(req, res, () => {
      resolve(undefined);
    });
  });
}